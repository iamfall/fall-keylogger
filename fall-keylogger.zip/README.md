# 🛰️ Fall Keylogger (Windows - C)

Este projeto é um **keylogger simples e funcional escrito em C**, utilizando a API nativa do Windows. Foi criado com fins **estritamente educacionais e científicos**, voltado a estudantes, pesquisadores de segurança da informação e analistas de malware.

> ⚠️ **ATENÇÃO:** Este software é fornecido apenas para estudo e análise em ambientes controlados. O uso em máquinas alheias ou sem autorização é ilegal.

## ✨ Funcionalidades

- Captura teclas pressionadas com `GetAsyncKeyState()`
- Salva entradas em `log.txt` no diretório AppData
- Persistência no registro (`HKCU\...\Run`)
- Esconde a janela de console na execução

## 🛠️ Compilação

### Requisitos:

- [MinGW](https://www.mingw-w64.org/) instalado e configurado no PATH
- GCC instalado e funcional

### Comando:

```bash
gcc keylogger.c -o fall_logger.exe -mwindows
```

> O flag `-mwindows` evita que o console apareça durante a execução.

## 🚀 Execução

1. Compile o programa.
2. Copie o `fall_logger.exe` para a pasta:
   ```
   C:\Users\<seu-usuário>\AppData\Roaming\
   ```
3. Execute-o manualmente uma vez. Ele:
   - Se esconde automaticamente
   - Cria um valor no registro do Windows para iniciar junto com o sistema
   - Começa a registrar as teclas digitadas em:
     ```
     C:\Users\<usuário>\AppData\Roaming\log.txt
     ```

## 📚 Finalidade Científica

Este projeto demonstra:

- Técnicas básicas de keylogging em nível de usuário
- Uso da WinAPI para persistência
- Estrutura limpa e compreensível para análise estática
- Base inicial para estudos em evasão de antivírus e detecção heurística

## 🔐 Considerações legais

Este projeto **não deve ser usado em ambientes reais ou em sistemas sem permissão explícita**.  
O uso é **exclusivamente educacional**.

## 📎 Hash do binário

Se optar por compilar o executável e testar localmente:

```
SHA256 (fall_logger.exe): SEU_HASH_AQUI
```

## 👤 Autor

Projeto por `Fall` — com objetivo de **explorar e contribuir com a ciência da cibersegurança ofensiva**.
